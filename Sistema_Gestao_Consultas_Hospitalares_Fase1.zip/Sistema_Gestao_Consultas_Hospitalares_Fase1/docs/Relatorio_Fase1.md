# Sistema de Gestão de Consultas Hospitalares
## Relatório técnico — Fase 1: Modelação e núcleo funcional

**Unidade curricular:** Programação Funcional  
**Linguagem:** Haskell  
**Elementos do grupo:** [preencher com os nomes]  
**Data:** [preencher]

## 1. Projeto

O projeto tem como objetivo desenvolver uma aplicação para organizar informação sobre pacientes e consultas hospitalares. A aplicação deverá permitir, ao longo das fases de desenvolvimento, consultar os dados dos pacientes, acompanhar as consultas associadas e apoiar a organização da informação.

Nesta primeira fase, o trabalho concentra-se na definição do modelo de domínio, na estrutura inicial do código e na implementação de operações funcionais básicas.

## 2. Requisitos iniciais

As funcionalidades previstas para o projeto são:

- registar e procurar pacientes;
- associar várias consultas a um paciente;
- consultar o conjunto de consultas de um paciente;
- identificar o estado de uma consulta;
- numa fase posterior, pesquisar consultas por data, médico ou especialidade;
- numa fase posterior, desenvolver estatísticas e persistência de dados em ficheiros.

Na Fase 1 foram implementadas a procura de um paciente por identificador, a listagem das consultas associadas a um paciente e a contagem dessas consultas.

## 3. Modelo de dados

O modelo é composto por duas entidades principais: `Paciente` e `Consulta`.

A entidade `Paciente` inclui o identificador, o nome, a idade e um contacto opcional. O contacto utiliza o tipo `Maybe String`, permitindo representar tanto a existência de contacto (`Just ...`) como a sua ausência (`Nothing`).

A entidade `Consulta` inclui um identificador próprio, data, hora, identificador do paciente associado, nome do médico, especialidade e estado. O estado é representado pelo tipo algébrico `EstadoConsulta`, com os valores `Marcada`, `Realizada` e `Cancelada`.

A relação entre as entidades é de um-para-muitos: um paciente pode ter várias consultas, mas cada consulta está associada a um único paciente através do campo `pacienteAssociado`. Não foi criada uma entidade `Medico`, uma vez que o âmbito inicial mantém o nome do médico e a especialidade diretamente na consulta.

Os dados apresentados no projeto são fictícios.

## 4. Arquitetura e organização dos módulos

O código está dividido em módulos com responsabilidades distintas:

- `Model`: definição das entidades e do tipo de estado da consulta;
- `DadosExemplo`: dados fictícios utilizados para demonstrar as funções;
- `Consultas`: funções puras para procurar pacientes, listar consultas e contar consultas;
- `Main`: demonstração das operações no terminal;
- `TestesFase1`: testes simples das funções implementadas.

Esta organização procura separar o modelo de dados, a lógica funcional e a interação com o terminal.

## 5. Programação funcional

As funções principais possuem assinaturas de tipo explícitas e não alteram os dados recebidos. A procura de pacientes e o processamento das consultas são realizados através de funções puras.

A recursão é utilizada para percorrer as listas. Cada função trata explicitamente o caso de lista vazia e o caso em que existe um primeiro elemento seguido do restante da lista. Esta abordagem demonstra pattern matching e recursão, conceitos centrais da primeira fase.

A função `procurarPaciente` devolve `Maybe Paciente`: retorna `Just paciente` quando encontra o identificador e `Nothing` quando não encontra. Assim, a ausência de um resultado é representada pelo tipo, em vez de se inventar um paciente.

## 6. Testes

Foram incluídos testes para verificar:
- a procura de um paciente existente;
- a pesquisa de um identificador inexistente;
- a obtenção das consultas de um paciente;
- a contagem de consultas;
- o comportamento quando a lista de consultas está vazia.

Os testes são executados através do ficheiro `test/TestesFase1.hs`.

## 7. Evolução prevista

Nas fases seguintes, o projeto poderá incluir pesquisa por data, médico e especialidade, validações de dados, estatísticas, utilização de funções de ordem superior como `map` e `filter`, folds e composição, tratamento explícito de erros e leitura/escrita de dados em ficheiros. Poderá também ser acrescentado um menu de interação no terminal.

## 8. Conclusão

A Fase 1 estabelece uma base funcional para o Sistema de Gestão de Consultas Hospitalares. O modelo representa as duas entidades essenciais e a sua relação, enquanto as funções implementadas permitem demonstrar operações básicas sobre os dados usando tipos explícitos, pattern matching e recursão.
