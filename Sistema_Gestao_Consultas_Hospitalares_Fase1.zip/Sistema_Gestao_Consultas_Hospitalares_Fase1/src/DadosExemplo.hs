module DadosExemplo
    ( pacientesExemplo
    , consultasExemplo
    ) where

import Model

-- | Lista pequena de pacientes fictícios para demonstração.
pacientesExemplo :: [Paciente]
pacientesExemplo =
    [ Paciente 1 "Ana Martins" 34 (Just "910000001")
    , Paciente 2 "Joao Ribeiro" 52 (Just "910000002")
    , Paciente 3 "Maria Costa" 27 Nothing
    ]

-- | Lista pequena de consultas fictícias para demonstração.
consultasExemplo :: [Consulta]
consultasExemplo =
    [ Consulta 101 "2026-11-05" "09:00" 1 "Dr. Rui Lopes" "Cardiologia" Marcada
    , Consulta 102 "2026-11-05" "10:30" 2 "Dra. Ines Silva" "Oftalmologia" Marcada
    , Consulta 103 "2026-11-07" "11:00" 1 "Dr. Rui Lopes" "Cardiologia" Realizada
    , Consulta 104 "2026-11-08" "14:00" 3 "Dra. Marta Reis" "Dermatologia" Cancelada
    ]
