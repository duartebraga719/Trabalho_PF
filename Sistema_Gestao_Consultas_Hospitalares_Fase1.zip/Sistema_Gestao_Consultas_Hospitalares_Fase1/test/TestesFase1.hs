module Main where

import Model
import DadosExemplo
import Consultas

assert :: String -> Bool -> IO ()
assert descricao condicao =
    if condicao
        then putStrLn ("[OK] " ++ descricao)
        else error ("[FALHOU] " ++ descricao)

main :: IO ()
main = do
    assert "Encontra paciente existente"
        (procurarPaciente 1 pacientesExemplo == Just (head pacientesExemplo))

    assert "Devolve Nothing para paciente inexistente"
        (procurarPaciente 99 pacientesExemplo == Nothing)

    assert "Paciente 1 tem duas consultas"
        (length (consultasDoPaciente 1 consultasExemplo) == 2)

    assert "Paciente 2 tem uma consulta"
        (contarConsultasPaciente 2 consultasExemplo == 1)

    assert "Paciente sem consultas tem zero consultas"
        (contarConsultasPaciente 99 consultasExemplo == 0)

    assert "Lista vazia não tem consultas"
        (consultasDoPaciente 1 [] == [])

    putStrLn ""
    putStrLn "Todos os testes da Fase 1 foram concluídos com sucesso."
